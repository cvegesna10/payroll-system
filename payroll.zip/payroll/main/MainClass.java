package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass1 {
	public static void main(String[] args) {
		PayrollServicesImpl payrollServices=new PayrollServicesImpl();
		int empId=payrollServices.acceptAssociateDetails("chandrahas", "vegesna", "java", "varma@gmail.com", "analyst", "BCGD98564",150000 ,50000, 1000, 1000, 212, "CITI", "SCGFDS546");
		System.out.println(empId);
		System.out.println(payrollServices.calculateNetSalary(empId));
		Associate a1=payrollServices.getAssociateDetails(empId);
		System.out.println(a1.getSalary().getGrossSalary()+"\n"+a1.getSalary().getMonthlyTax()+"\n");
		
	}
}
